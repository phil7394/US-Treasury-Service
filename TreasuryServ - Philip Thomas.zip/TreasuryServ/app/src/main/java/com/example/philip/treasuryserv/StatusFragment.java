/*
 * Copyright (c) 2017. Created by Philip Joseph Thomas.
 */

package com.example.philip.treasuryserv;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * StatusFragment that displays the service status uses
 * a broadcast receiver to listen to status update
 * broadcasts sent by the service.
 */
public class StatusFragment extends Fragment {
    // broadcast intent filter action
    public static final String BROADCAST_ACTION = "com.example.philip.treasuryserv.UPDATE_UI";
    // status flags
    private static boolean isBound = false;
    private static boolean isBusy = false;
    private static boolean isDestroyed = true;

    // broad cast receiver
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i("### TrsryServMnActivity", "onReceive");
            // update the status flags
            updateFlags(intent);

            if (getActivity() != null) {
                // update UI
                updateServiceStatus();
            }
        }
    };

    public StatusFragment() {
        // Required empty public constructor
    }

    /**
     * update the status flags using intent extras
     *
     * @param intent
     */
    private void updateFlags(Intent intent) {
        isDestroyed = intent.getBooleanExtra("IS_DESTROYED", true);
        isBound = intent.getBooleanExtra("IS_BOUND", false);
        isBusy = intent.getBooleanExtra("IS_BUSY", false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_status, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setRetainInstance(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        Log.i("### TrsryServMnActivity", "onActivityCreated");
        // register receiver
        getActivity().registerReceiver(broadcastReceiver, new IntentFilter(BROADCAST_ACTION));
        // update UI
        updateServiceStatus();
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    /**
     * update the service status view
     */
    public void updateServiceStatus() {
        Log.i("### TrsryServMnActivity", "updateServiceStatus");

        TextView servStatus = (TextView) getActivity().findViewById(R.id.servStat);
        Log.i("### TrsryServMnActivity", "isDestroyed = " + isDestroyed + ", isBound = " + isBound + ", isBusy = " + isBusy);
        if (servStatus != null) {
            if (isDestroyed) {
                Log.i("### TrsryServMnActivity", "Destroyed");
                servStatus.setText(R.string.destroyed);
            } else if (!isBound) {
                Log.i("### TrsryServMnActivity", "Unbound");
                servStatus.setText(R.string.unbound);
            } else if (isBusy) {
                Log.i("### TrsryServMnActivity", "Bound and busy");
                servStatus.setText(R.string.boundAndBusy);
            } else {
                Log.i("### TrsryServMnActivity", "Bound and idle");
                servStatus.setText(R.string.boundAndIdle);
            }
        }
    }
}
