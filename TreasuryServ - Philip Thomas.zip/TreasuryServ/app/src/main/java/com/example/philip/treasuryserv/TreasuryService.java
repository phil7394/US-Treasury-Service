/*
 * Copyright (c) 2017. Created by Philip Joseph Thomas.
 * U.S. Treasury data via Treasury.io.
 */

package com.example.philip.treasuryserv;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * TreasuryService that implements ITreasuryService aidl
 */
public class TreasuryService extends Service {

    // url prefix
    final String prefixUrl = "http://api.treasury.io/cc7znvq/47d80ae900e04f2/sql/?q=";
    // service handler
    private final Handler handler = new Handler();
    // broadcast intent
    Intent broadcastIntent;
    // binder instance
    private final ITreasuryService.Stub mBinder = new ITreasuryService.Stub() {


        @Override
        public synchronized int[] monthlyCash(int year) throws RemoteException {
            Log.i("### TreasuryService", "monthlyCash API");
            // update status
            onMethodStart();
            int[] results = null;
            // build url with query
            StringBuilder urlStr = new StringBuilder();
            urlStr.append(prefixUrl);
            StringBuilder query = new StringBuilder();
            query.append("SELECT open_today FROM t1 WHERE date IN (SELECT min(date) FROM t1 WHERE year = \"");
            query.append(year);
            query.append("\" and account = \"Federal Reserve Account\" GROUP BY year_month) and account = \"Federal Reserve Account\"");

            try {
                // encode url
                urlStr.append(URLEncoder.encode(query.toString(), "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            URL url = null;
            HttpURLConnection urlConnection = null;
            try {
                url = new URL(urlStr.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            try {
                // connect and get response
                if (url != null) {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                }
                if (urlConnection != null && urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {

                    String responseString = "";
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            urlConnection.getInputStream()));
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        responseString = responseString + inputLine;
                    }
                    Log.i("### TreasuryService", "responseString  = " + responseString);

                    try {
                        // parse JSON response
                        JSONArray jsonArr = new JSONArray(responseString);
                        results = new int[jsonArr.length()];
                        for (int i = 0; i < jsonArr.length(); i++) {
                            results[i] = jsonArr.getJSONObject(i).getInt("open_today");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    in.close();
                    urlConnection.disconnect();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            // update status
            onMethodEnd();
            return results;
        }

        @Override
        public synchronized int[] dailyCash(int day, int month, int year, int workingDays) throws RemoteException {
            // update status
            onMethodStart();
            int[] results = null;
            StringBuilder urlStr = new StringBuilder();
            // build url with query
            urlStr.append(prefixUrl);
            StringBuilder query = new StringBuilder();
            query.append("SELECT open_today FROM t1 WHERE date IN (SELECT date FROM t1 WHERE date >= \"");
            query.append(year).append("-").append(month).append("-").append(day);
            query.append("\" and account = \"Federal Reserve Account\" ORDER BY date LIMIT ");
            query.append(workingDays + 1);
            query.append(") and account = \"Federal Reserve Account\"");

            try {
                // encode url
                urlStr.append(URLEncoder.encode(query.toString(), "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            URL url = null;
            HttpURLConnection urlConnection = null;
            try {
                url = new URL(urlStr.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            // connect and get response
            try {
                if (url != null) {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                }
                if (urlConnection != null && urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String responseString = "";
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            urlConnection.getInputStream()));
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        responseString = responseString + inputLine;
                    }
                    Log.i("### TreasuryService", "responseString  = " + responseString);

                    try {
                        //parse JSON response
                        JSONArray jsonArr = new JSONArray(responseString);
                        results = new int[jsonArr.length()];
                        for (int i = 0; i < jsonArr.length(); i++) {
                            results[i] = jsonArr.getJSONObject(i).getInt("open_today");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    in.close();
                    urlConnection.disconnect();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            //update status
            onMethodEnd();
            return results;

        }

        @Override
        public synchronized int yearlyAvg(int year) throws RemoteException {
            // update status
            onMethodStart();
            int result = -1;
            StringBuilder urlStr = new StringBuilder();
            // build url with query
            urlStr.append(prefixUrl);
            StringBuilder query = new StringBuilder();
            query.append("SELECT AVG(open_today) FROM t1 WHERE year = \"");
            query.append(year);
            query.append("\" and account is \"Federal Reserve Account\"");

            try {
                // encode url
                urlStr.append(URLEncoder.encode(query.toString(), "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            URL url = null;
            HttpURLConnection urlConnection = null;
            try {
                url = new URL(urlStr.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            try {
                // connect and get response
                if (url != null) {
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.connect();
                }
                if (urlConnection != null && urlConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String responseString = "";
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            urlConnection.getInputStream()));
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        responseString = responseString + inputLine;
                    }
                    Log.i("### TreasuryService", "responseString  = " + responseString);

                    try {
                        // parse JSON response
                        JSONArray jsonArr = new JSONArray(responseString);
                        result = jsonArr.getJSONObject(0).getInt("AVG(open_today)");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    in.close();
                    urlConnection.disconnect();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            // update status
            onMethodEnd();
            return result;

        }
    };

    public TreasuryService() {
        super();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // set broadcast intent
        broadcastIntent = new Intent(StatusFragment.BROADCAST_ACTION);
    }

    /**
     * destroy and update status
     */
    public void onDestroy() {
        Log.i("### TreasuryService", "Service was destroyed!!!!");

        handler.post(new Runnable() {
            @Override
            public void run() {
                broadcastIntent.putExtra("IS_DESTROYED", true);
                broadcastIntent.putExtra("IS_BOUND", false);
                broadcastIntent.putExtra("IS_BUSY", false);
                sendBroadcast(broadcastIntent);
            }
        });

        super.onDestroy();

    }

    /**
     * bind and update status
     *
     * @param bindIntent
     * @return
     */
    @Override
    public IBinder onBind(Intent bindIntent) {
        Log.i("### TreasuryService", "onBind !");

        handler.post(new Runnable() {
            @Override
            public void run() {
                broadcastIntent.putExtra("IS_DESTROYED", false);
                broadcastIntent.putExtra("IS_BOUND", true);
                broadcastIntent.putExtra("IS_BUSY", false);
                sendBroadcast(broadcastIntent);
            }
        });

        Log.i("### TreasuryService", "onBind ! sent broadcast");
        return mBinder;
    }

    /**
     * unbind and update status
     *
     * @param bindIntent
     * @return
     */
    @Override
    public boolean onUnbind(Intent bindIntent) {
        Log.i("### TreasuryService", "onUnbind !");
        handler.post(new Runnable() {
            @Override
            public void run() {
                broadcastIntent.putExtra("IS_DESTROYED", false);
                broadcastIntent.putExtra("IS_BOUND", false);
                broadcastIntent.putExtra("IS_BUSY", false);
                sendBroadcast(broadcastIntent);
                // add delay to perceive status change
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });

        return super.onUnbind(bindIntent);
    }

    /**
     * update status on method start
     */
    public void onMethodStart() {

        handler.post(new Runnable() {
            @Override
            public void run() {
                broadcastIntent.putExtra("IS_DESTROYED", false);
                broadcastIntent.putExtra("IS_BOUND", true);
                broadcastIntent.putExtra("IS_BUSY", true);
                sendBroadcast(broadcastIntent);
            }
        });

        // add delay to perceive status change
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    /**
     * update status on method end
     */
    public void onMethodEnd() {

        handler.post(new Runnable() {
            @Override
            public void run() {
                broadcastIntent.putExtra("IS_DESTROYED", false);
                broadcastIntent.putExtra("IS_BOUND", true);
                broadcastIntent.putExtra("IS_BUSY", false);
                sendBroadcast(broadcastIntent);
            }
        });

    }
}

