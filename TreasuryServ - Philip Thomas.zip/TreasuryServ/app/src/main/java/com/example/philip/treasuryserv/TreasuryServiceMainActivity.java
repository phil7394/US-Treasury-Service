/*
 * Copyright (c) 2017. Created by Philip Joseph Thomas.
 */

package com.example.philip.treasuryserv;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * TreasuryServiceMainActivity that contains a fragment
 * to display the status of the service.
 */
public class TreasuryServiceMainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treasury_service_main);

        FragmentManager mFragmentManager = getFragmentManager();

        // Start a new FragmentTransaction
        FragmentTransaction fragmentTransaction = mFragmentManager
                .beginTransaction();

        // Get the reference to StatusFragment
        StatusFragment mStatusFragment = (StatusFragment) mFragmentManager.findFragmentById(R.id.status_framelayout);

        // if mStatusFragment is null, create new instance
        if (mStatusFragment == null) {
            mStatusFragment = new StatusFragment();
        }
        // Add the mStatusFragment to the layout
        // using replace() instead of add() to avoid overlapping fragments
        fragmentTransaction.replace(R.id.status_framelayout,
                mStatusFragment);

        // Commit the FragmentTransaction
        fragmentTransaction.commit();

    }

}
