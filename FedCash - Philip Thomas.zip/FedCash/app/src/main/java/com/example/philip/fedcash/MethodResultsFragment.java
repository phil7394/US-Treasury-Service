/*
 * Copyright (c) 2017. Created by Philip Joseph Thomas.
 */

package com.example.philip.fedcash;


import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * MethodResultsFragment to display the result
 * of each service call made.
 */
public class MethodResultsFragment extends Fragment {


    private static final String TAG = "MethodResultsFragment";
    private TextView mResultsView = null;
    private int mCurrIdx = -1;
    private int mResultsListLen;

    public MethodResultsFragment() {
        // Required empty public constructor
    }

    /**
     * get the selected index
     *
     * @return
     */
    int getShownIndex() {
        return mCurrIdx;
    }

    /**
     * Show the result at position newIndex
     *
     * @param newIndex
     */
    void showResultAtIndex(int newIndex) {
        // check for valid index
        if (newIndex < 0 || newIndex >= mResultsListLen) {
            return;
        }

        mCurrIdx = newIndex;

        Log.i(TAG, getClass().getSimpleName() + "result index = " + mCurrIdx);

        mResultsView.setText(FedCashHistoryActivity.mMethodResultsList.get(mCurrIdx));

    }

    /**
     * @param savedInstanceState
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, getClass().getSimpleName() + ":onCreate()");
        super.onCreate(savedInstanceState);

        // Retain this Fragment across Activity reconfigurations
        setRetainInstance(true);

    }

    /**
     * Called to create the content view for this Fragment
     *
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.i(TAG, getClass().getSimpleName() + ":entered onCreateView()");

        // Inflate the layout defined in method_results_item.xml
        // The last parameter is false because the returned view does not need to be attached to the container ViewGroup
        return inflater.inflate(R.layout.method_results_item, container, false);
    }

    /**
     * Set up some information about the mResultsView TextView
     *
     * @param savedInstanceState
     **/
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        Log.i(TAG, getClass().getSimpleName() + ":entered onActivityCreated()");
        super.onActivityCreated(savedInstanceState);

        mResultsView = (TextView) getActivity().findViewById(R.id.results_view);
        mResultsListLen = FedCashHistoryActivity.mMethodResultsList.size();

        showResultAtIndex(mCurrIdx);

    }
}
