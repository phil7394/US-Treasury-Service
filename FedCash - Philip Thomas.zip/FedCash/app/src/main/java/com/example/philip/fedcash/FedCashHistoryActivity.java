/*
 * Copyright (c) 2017. Created by Philip Joseph Thomas.
 */

package com.example.philip.fedcash;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.List;

/**
 * FedCashHistoryActivity with two fragments to display history of service
 * calls and results.
 */
public class FedCashHistoryActivity extends AppCompatActivity implements MethodCallsFragment.ListSelectionListener {

    private static final int MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final String LOG_TAG = "FragmentActivity";


    public static List<String> mMethodCallsList;
    public static List<String> mMethodResultsList;

    private MethodResultsFragment mMethodResultsFragment;

    private FragmentManager mFragmentManager;
    private FrameLayout mMethodCallsFrameLayout, mMethodResultsFrameLayout;

    /**
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.i(LOG_TAG, getClass().getSimpleName() + ":entered onCreate()");

        super.onCreate(savedInstanceState);

        // get the lists
        mMethodCallsList = getIntent().getStringArrayListExtra(FedCashMainActivity.LIST_OF_ALL_CALLS);
        mMethodResultsList = getIntent().getStringArrayListExtra(FedCashMainActivity.LIST_OF_ALL_RESULTS);

        //set the content view for this activity
        setContentView(R.layout.activity_fed_cash_history);

        mMethodCallsFrameLayout = (FrameLayout) findViewById(R.id.method_calls_framelayout);
        mMethodResultsFrameLayout = (FrameLayout) findViewById(R.id.method_results_framelayout);

        // Get a reference to the FragmentManager
        mFragmentManager = getFragmentManager();

        // Start a new FragmentTransaction
        FragmentTransaction fragmentTransaction = mFragmentManager
                .beginTransaction();

        // Get the reference to MethodCallsFragment
        MethodCallsFragment mMethodCallsFragment = (MethodCallsFragment) mFragmentManager.findFragmentById(R.id.method_calls_framelayout);

        // if mMethodCallsFragment is null, create new instance
        if (mMethodCallsFragment == null) {
            mMethodCallsFragment = new MethodCallsFragment();
        }
        // Add the mMethodCallsFragment to the layout
        // using replace() instead of add() to avoid overlapping fragments
        fragmentTransaction.replace(R.id.method_calls_framelayout,
                mMethodCallsFragment);

        // Commit the FragmentTransaction
        fragmentTransaction.commit();

        // Add a OnBackStackChangedListener to reset the layout when the back stack changes
        mFragmentManager
                .addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
                    public void onBackStackChanged() {

                        setLayout();
                    }
                });

        // Get the reference to MethodResultsFragment
        mMethodResultsFragment = (MethodResultsFragment) mFragmentManager.findFragmentById(R.id.method_results_framelayout);

        // if mMethodResultsFragment is null, create new instance
        if (mMethodResultsFragment == null) {
            mMethodResultsFragment = new MethodResultsFragment();
        }

        // set the layout depending on orientation
        setLayout();
    }

    /**
     * sets the layout depending on the orientation
     */
    private void setLayout() {
        // for portrait mode
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            Log.i(LOG_TAG, getClass().getSimpleName() + ": setLayout() --> PORTRAIT");
            // checking if mMethodResultsFragment was already added
            if (!mMethodResultsFragment.isAdded()) {
                Log.i(LOG_TAG, getClass().getSimpleName() + ": setLayout() --> mMethodResultsFragment is not Added()");
                // set dimensions of mMethodCallsFrameLayout so as to cover the whole container
                mMethodCallsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        MATCH_PARENT, MATCH_PARENT));
                // set dimensions of mMethodResultsFrameLayout so as to be hidden
                mMethodResultsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT));
            } else {
                Log.i(LOG_TAG, getClass().getSimpleName() + ": setLayout() --> mMethodResultsFragment is Added()");
                // set dimensions of mMethodCallsFrameLayout so as to be hidden
                mMethodCallsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT));
                // set dimensions of mMethodResultsFrameLayout so as to cover the whole container
                mMethodResultsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT,
                        MATCH_PARENT));
            }
        }
        // for landscape mode
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.i(LOG_TAG, getClass().getSimpleName() + ": setLayout() --> LANDSCAPE");
            // checking if mMethodResultsFragment was already added
            if (!mMethodResultsFragment.isAdded()) {
                Log.i(LOG_TAG, getClass().getSimpleName() + ": setLayout() --> mMethodResultsFragment is not Added()");
                // set dimensions of mMethodCallsFrameLayout so as to cover the whole container
                mMethodCallsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        MATCH_PARENT, MATCH_PARENT));
                // set dimensions of mMethodResultsFrameLayout so as to be hidden
                mMethodResultsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT));
            } else {
                Log.i(LOG_TAG, getClass().getSimpleName() + ": setLayout() --> mMethodResultsFragment is Added()");
                // Make the mMethodCallsFrameLayout take 1/3 of the layout's width
                mMethodCallsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 1f));
                // Make the mMethodResultsFrameLayout take 2/3's of the layout's width
                mMethodResultsFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 2f));
            }
        }
    }

    /**
     * Called when the user selects an item in the MethodCallsFragment
     **/
    @Override
    public void onListSelection(int index) {

        // If the MethodResultsFragment has not been added, add it now
        if (!mMethodResultsFragment.isAdded()) {

            // Start a new FragmentTransaction
            FragmentTransaction fragmentTransaction = mFragmentManager
                    .beginTransaction();

            // Add the MethodResultsFragment to the layout
            fragmentTransaction.replace(R.id.method_results_framelayout,
                    mMethodResultsFragment);

            // Add this FragmentTransaction to the backstack
            fragmentTransaction.addToBackStack(null);

            // Commit the FragmentTransaction
            fragmentTransaction.commit();

            // Force Android to execute the committed FragmentTransaction
            mFragmentManager.executePendingTransactions();
        }

        // check if the index currently displayed is the same
        // as the index to be displayed
        if (mMethodResultsFragment.getShownIndex() != index) {

            // Tell the MethodResultsFragment to show the webpage at position index
            mMethodResultsFragment.showResultAtIndex(index);

        }
    }

    /**
     * when back button is pressed, set the layout for MethodCallsFragment
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.i(LOG_TAG, getClass().getSimpleName() + ": onBackPressed()");
        // get fragment transaction
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        // replace MethodCallsFragment with new instance with no item selected
        fragmentTransaction.replace(R.id.method_calls_framelayout, new MethodCallsFragment());
        // commit transaction
        fragmentTransaction.commit();
        // execute immediately
        mFragmentManager.executePendingTransactions();

    }
}
