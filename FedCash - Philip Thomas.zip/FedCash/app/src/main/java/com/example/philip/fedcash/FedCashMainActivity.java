/*
 * Copyright (c) 2017. Created by Philip Joseph Thomas.
 */

package com.example.philip.fedcash;

import android.app.DatePickerDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.philip.treasuryserv.ITreasuryService;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * FedCash Main activity.
 * Requests date/year input from user and calls TreasuryServ APIs.
 */
public class FedCashMainActivity extends AppCompatActivity {

    public static final String LIST_OF_ALL_CALLS = "list_of_all_calls";
    public static final String LIST_OF_ALL_RESULTS = "list_of_all_results";
    private static final int MONTHLY_CASH = 1;
    private static final int DAILY_CASH = 2;
    private static final int YEARLY_AVG = 3;
    private static final String BIND_INTENT_ACTION = "com.example.philip.treasuryserv.TreasuryService";
    // state flag to track bind status
    private boolean mBound;
    // service instance
    private ITreasuryService boundService;
    // service connection instance
    private ServiceConnection mConnection;
    // main Ui thread handler
    private Handler mainHandler = new Handler();
    // client thread handler
    private Handler mClientHandler;
    // store all the calls made in listOfAllCalls
    private List<String> listOfAllCalls = new ArrayList<>();
    // store all the results made in listOfAllResults
    private List<String> listOfAllResults = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            listOfAllCalls = savedInstanceState.getStringArrayList(LIST_OF_ALL_CALLS);
            listOfAllResults = savedInstanceState.getStringArrayList(LIST_OF_ALL_RESULTS);
        }
        setContentView(R.layout.activity_fed_cash_main);
        Log.i("### FedCashMainActivity", "onCreate()");
        mBound = false;
        //get service connection instance
        mConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                boundService = ITreasuryService.Stub.asInterface(service);
                Log.i("### ITreasuryService", "onServiceConnected");
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                boundService = null;
                Log.i("### ITreasuryService", "onServiceDisconnected");
            }
        };

        FedCashClientThread mClientThread = new FedCashClientThread("Client Thread");
        mClientThread.start();

        //wait till client handler is ready
        while (mClientHandler == null) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            mClientHandler = mClientThread.mHandler;
        }

    }

    /**
     * set the date/year views, on date picker clicked
     *
     * @param view
     */
    public void onDatePickerClicked(final View view) {
        // date set listener
        DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                view.requestFocus();
                ((TextView) view).setError(null);
                month = month + 1;
                Log.d("### FedCashMainActivity", "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);
                String date;
                if (view.getId() == R.id.enterDateField) {
                    date = month + "/" + day + "/" + year;
                } else {
                    date = "" + year;
                }

                ((TextView) findViewById(view.getId())).setText(date);
            }
        };

        Calendar cal = Calendar.getInstance();
        cal.set(2005, 0, 1);
        // dialog for date picker
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                mDateSetListener,
                2005, 0, 1);
        dialog.getDatePicker().setMinDate(cal.getTimeInMillis());
        cal.set(2016, 11, 31);
        dialog.getDatePicker().setMaxDate(cal.getTimeInMillis());

        // for year pickers, hide day and month
        if (view.getId() != R.id.enterDateField) {

            dialog.getDatePicker().findViewById(Resources.getSystem().getIdentifier("day", "id", "android")).setVisibility(View.GONE);
            dialog.getDatePicker().findViewById(Resources.getSystem().getIdentifier("month", "id", "android")).setVisibility(View.GONE);

        }
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialog.show();
    }


    /**
     * validate year input and send message to client handler,
     * on monthly cash go button clicked
     *
     * @param view
     * @throws RemoteException
     */
    public void onMonthlyCashBtnClicked(View view) throws RemoteException {
        Log.i("### FedCashMainActivity", "onMonthlyCashBtnClicked");
        TextView yearField = (TextView) findViewById(R.id.enterYearField1);
        final String year = yearField.getText().toString();

        //validation
        if (year.isEmpty()) {
            yearField.requestFocus();
            yearField.setError("Year cannot be empty!");
        } else {

            yearField.setError(null);
            // bind service if not bound
            if (!mBound) {
                mClientHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Log.i("### mClientThread", "run()");
                        Intent i = new Intent(BIND_INTENT_ACTION);
                        ResolveInfo info = getPackageManager().resolveService(i, PackageManager.MATCH_ALL);
                        if (info != null) {
                            i.setComponent(new ComponentName(info.serviceInfo.packageName, info.serviceInfo.name));
                            Log.i("### mClientThread", "calling bindService()");
                            mBound = bindService(i, mConnection, Context.BIND_AUTO_CREATE);
                            Log.i("### mClientThread", "didBind = " + mBound);
                            if (mBound) {
                                Message monthlyCashMsg = mClientHandler.obtainMessage(MONTHLY_CASH, 0, 0, year);
                                mClientHandler.sendMessage(monthlyCashMsg);
                            } else {
                                Toast.makeText(getApplicationContext(), "Service failed to bind!", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "TreasuryServ app is not installed!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            } else {
                Message monthlyCashMsg = mClientHandler.obtainMessage(MONTHLY_CASH, 0, 0, year);
                mClientHandler.sendMessage(monthlyCashMsg);
            }

        }
    }


    /**
     * validate date and working days input and send message to client handler,
     * on daily cash go button clicked
     *
     * @param view
     * @throws RemoteException
     */
    public void onDailyCashBtnClicked(View view) throws RemoteException {
        if (getCurrentFocus() != null) {
            getCurrentFocus().clearFocus();
        }

        TextView dateField = (TextView) findViewById(R.id.enterDateField);
        String date = dateField.getText().toString();
        String[] dateArr = date.split("/");
        EditText workingDayField = (EditText) findViewById(R.id.workingDaysField);
        String workingDaysStr = workingDayField.getText().toString();

        // validation
        if (date.isEmpty()) {
            dateField.requestFocus();
            dateField.setError("Date cannot be empty!");
        } else if (workingDaysStr.isEmpty()) {
            dateField.setError(null);
            workingDayField.requestFocus();
            workingDayField.setError("Enter value between 5 and 25!");
        } else {
            dateField.setError(null);
            workingDayField.setError(null);
            int workingDays = Integer.parseInt(workingDaysStr);
            if (workingDays < 5 || workingDays > 25) {
                workingDayField.requestFocus();
                workingDayField.setError("Enter value between 5 and 25!");
            } else {
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(workingDayField.getWindowToken(), 0);
                final int[] inputArr = {Integer.parseInt(dateArr[0]),
                        Integer.parseInt(dateArr[1]),
                        Integer.parseInt(dateArr[2]),
                        workingDays};
                // bind service if not bound
                if (!mBound) {
                    mClientHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Log.i("### mClientThread", "run()");
                            Intent i = new Intent(BIND_INTENT_ACTION);
                            ResolveInfo info = getPackageManager().resolveService(i, PackageManager.MATCH_ALL);
                            if (info != null) {
                                i.setComponent(new ComponentName(info.serviceInfo.packageName, info.serviceInfo.name));
                                Log.i("### mClientThread", "calling bindService()");
                                mBound = bindService(i, mConnection, Context.BIND_AUTO_CREATE);
                                Log.i("### mClientThread", "didBind = " + mBound);
                                if (mBound) {
                                    Message dailyCashMsg = mClientHandler.obtainMessage(DAILY_CASH, 0, 0, inputArr);
                                    mClientHandler.sendMessage(dailyCashMsg);
                                } else {
                                    Toast.makeText(getApplicationContext(), "Service failed to bind!", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "TreasuryServ app is not installed!", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                } else {
                    Message dailyCashMsg = mClientHandler.obtainMessage(DAILY_CASH, 0, 0, inputArr);
                    mClientHandler.sendMessage(dailyCashMsg);
                }
            }
        }
    }

    /**
     * validate year input and send message to client handler,
     * on yearly average go button clicked
     *
     * @param view
     * @throws RemoteException
     */
    public void onYearlyAvgBtnClicked(View view) throws RemoteException {
        TextView yearField = (TextView) findViewById(R.id.enterYearField2);
        final String year = yearField.getText().toString();
        // validation
        if (year.isEmpty()) {
            yearField.requestFocus();
            yearField.setError("Year cannot be empty!");
        } else {
            yearField.setError(null);
            // bind service if not bound
            if (!mBound) {
                mClientHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Log.i("### mClientThread", "run()");
                        Intent i = new Intent(BIND_INTENT_ACTION);
                        ResolveInfo info = getPackageManager().resolveService(i, PackageManager.MATCH_ALL);
                        if (info != null) {
                            i.setComponent(new ComponentName(info.serviceInfo.packageName, info.serviceInfo.name));
                            Log.i("### mClientThread", "calling bindService()");
                            mBound = bindService(i, mConnection, Context.BIND_AUTO_CREATE);
                            Log.i("### mClientThread", "didBind = " + mBound);
                            if (mBound) {
                                Message yearlyAvgMsg = mClientHandler.obtainMessage(YEARLY_AVG, 0, 0, year);
                                mClientHandler.sendMessage(yearlyAvgMsg);
                            } else {
                                Toast.makeText(getApplicationContext(), "Service failed to bind!", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "TreasuryServ app is not installed!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            } else {
                Message yearlyAvgMsg = mClientHandler.obtainMessage(YEARLY_AVG, 0, 0, year);
                mClientHandler.sendMessage(yearlyAvgMsg);
            }

        }
    }

    /**
     * unbind service, on unbind button clicked
     *
     * @param view
     */
    public void onUnbindBtnClicked(View view) {
        if (mConnection != null && mBound) {
            Log.i("### FedCashMainActivity", "unbinding service...");
            unbindService(mConnection);
            mBound = false;
        }
        Toast.makeText(this, "Service unbound!", Toast.LENGTH_SHORT).show();

    }

    /**
     * start FedCashHistory activity, on history button clicked
     *
     * @param view
     */
    public void onHistoryBtnClicked(View view) {
        Intent historyIntent = new Intent(this, FedCashHistoryActivity.class);
        historyIntent.putStringArrayListExtra(LIST_OF_ALL_CALLS, (ArrayList<String>) listOfAllCalls);
        historyIntent.putStringArrayListExtra(LIST_OF_ALL_RESULTS, (ArrayList<String>) listOfAllResults);
        startActivity(historyIntent);
    }

    /**
     * unbind service and disconnect, on activity destroyed
     */
    @Override
    protected void onDestroy() {
        if (mConnection != null && mBound) {
            Log.i("### FedCashMainActivity", "unbinding service...");
            unbindService(mConnection);
            mBound = false;

        }
        mConnection = null;
        super.onDestroy();
    }

    /**
     * save the history on configuration changes
     *
     * @param outState
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putStringArrayList(LIST_OF_ALL_CALLS, (ArrayList<String>) listOfAllCalls);
        outState.putStringArrayList(LIST_OF_ALL_RESULTS, (ArrayList<String>) listOfAllResults);
        super.onSaveInstanceState(outState);
    }

    /**
     * client handler thread
     */
    private class FedCashClientThread extends HandlerThread {

        // client handler
        Handler mHandler;

        FedCashClientThread(String name) {
            super(name);
        }

        @Override
        protected void onLooperPrepared() {
            super.onLooperPrepared();
            mHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    Log.i("### FedCashClientThread", "handleMessage");
                    // wait till service gets connected
                    while (boundService == null) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    switch (msg.what) {
                        case MONTHLY_CASH:
                            int mcYear = -1;
                            int[] mcResult = null;

                            try {
                                mcYear = Integer.parseInt((String) msg.obj);
                                // call service method
                                mcResult = boundService.monthlyCash(mcYear);
                            } catch (RemoteException re) {
                                Log.i("FedCashMainActivity", "Service invocation failed");
                            }

                            // build call and result strings
                            if (mcResult != null) {
                                final String mcMethodCall = "monthlyCash(" + mcYear + ")";
                                String mcResultStr = "";
                                for (int aMcResult : mcResult) {
                                    mcResultStr = mcResultStr + aMcResult + "\n";
                                }
                                final String mcMethodResult = mcResultStr;

                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        // add call and result ot the lists
                                        listOfAllCalls.add(mcMethodCall);
                                        listOfAllResults.add(mcMethodResult);
                                        Toast.makeText(FedCashMainActivity.this, "monthlyCash returned", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }

                            break;
                        case DAILY_CASH:
                            int[] inputArr = (int[]) msg.obj;
                            int dcDay = inputArr[0];
                            int dcMonth = inputArr[1];
                            int dcYear = inputArr[2];
                            int dcWorkingDays = inputArr[3];
                            int[] dcResult = null;

                            try {
                                // call service method
                                dcResult = boundService.dailyCash(dcDay, dcMonth, dcYear, dcWorkingDays);
                            } catch (RemoteException re) {
                                Log.i("FedCashMainActivity", "Service invocation failed");
                            }
                            // build call and result strings
                            if (dcResult != null) {
                                final String dcMethodCall = "dailyCash(" + dcDay + ", " + dcMonth + ", " + dcYear + ", " + dcWorkingDays + ")";
                                String dcResultStr = "";
                                for (int aDcResult : dcResult) {
                                    dcResultStr = dcResultStr + aDcResult + "\n";
                                }
                                final String dcMethodResult = dcResultStr;

                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        // add call and result to the lists
                                        listOfAllCalls.add(dcMethodCall);
                                        listOfAllResults.add(dcMethodResult);
                                        Toast.makeText(FedCashMainActivity.this, "dailyCash returned", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }

                            break;
                        case YEARLY_AVG:
                            int yaResult = -1;
                            int yaYear = Integer.parseInt((String) msg.obj);

                            try {
                                // call service method
                                yaResult = boundService.yearlyAvg(yaYear);
                            } catch (RemoteException re) {
                                Log.i("FedCashMainActivity", "Service invocation failed");
                            }
                            //build call and result strings
                            if (yaResult != -1) {
                                final String yaMethodCall = "yearlyAvg(" + yaYear + ")";
                                final String yaMethodResult = String.valueOf(yaResult);

                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        // add call and result to the lists
                                        listOfAllCalls.add(yaMethodCall);
                                        listOfAllResults.add(yaMethodResult);
                                        Toast.makeText(FedCashMainActivity.this, "yearlyAvg returned", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }

                            break;
                        default:
                            super.handleMessage(msg);

                    }

                }
            };

        }

    }
}

